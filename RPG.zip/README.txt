RPG game - By Kasper Sylvest Worm

Instructions on how to run can be found here
https://github.com/KSWorm93/RPG